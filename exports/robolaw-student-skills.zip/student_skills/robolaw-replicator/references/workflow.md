# 独立任务组工作约定 v1

开发与交付前先读 [2026-10-22 复查后的验收要求](review-gates.md)；本页的历史单基线 accepted 不能覆盖新增场景物理质量与稳定必要性检查。

## 范围与独立性
本技能负责 assignment.json 中列出的全部原始环境，每个环境完整交付：资产/场景 → 安全增广 → cuRobo规划与物理执行 → 三路RGB采集 → 验证。其他三位同学从同一源码基线独立工作；没有先后依赖，不等待任何人重构公共框架。不扩大为31环境总重构。
原始范例是 Lightwheel one-wall coastal 的 mustard→bowl，6财产+4机器人周边+1默认MPFB人体。技能创建时最初以该任务作为扩展范例，四组首任务现另有局部实测入口；本组后续有效避障范围优先见 avoidance-trial.md，verified-trial.md 仅为旧物理流程记录；每变体200条是项目背景，本仓库没有附带这批数据，不把背景当作本机验证结果。

## 开始工作
1. 检查 git status、remote、当前commit；确认origin为RoboLaw后先执行 `git remote set-branches --add origin ylj`，再执行 `git fetch origin refs/heads/ylj:refs/remotes/origin/ylj`。由学生自己从 `origin/ylj` 创建以本人姓名缩写命名的个人分支，例如 `zxw`、`lgd`、`lwx`；姓名未提供时先询问，不按组号猜测。将已确认姓名赋给 `student_branch` 后，在干净的独立工作区执行 `git switch --no-track -c "$student_branch" origin/ylj`。已有同名个人分支先检查并沿用；远程已有时先将本人分支加入origin获取规则并显式fetch，再跟踪或合入个人远程历史（single-branch克隆也适用），必要时合并 `origin/ylj`，不强制覆盖、不reset、不删除或自动stash未提交文件。`assignment.json.branch` 为null表示由学生提供实际名称，`branch_naming`记录命名规则；base_commit只作来源追溯，不退回旧提交。首次推送执行 `git push -u origin "$student_branch"`，成功后执行 `git remote set-branches --add origin "$student_branch"`，使后续普通fetch获取本人远程分支。不要将本机绝对路径、容器名或第三方源码路径当成同学机器的既定环境。
2. 先读 SKILL.md、assignment.json 和本文件，在仓库根目录运行随技能的 preflight.py。技能目录与仓库目录可能不同，明确传 --repo；预检不下载、改分支或启动GPU。
3. 阅读分配给自己的原始 YAML 及其中 task kind 的源码，保留源任务对象、机器人位置关系、支座高度、相机与成功predicate。检查资产恢复情况。preflight仅证明清单与源码一致，不证明其余厨房资产已恢复或仿真可运行。
4. README提供源码/资产恢复与安装入口。默认 assets/kitchen/scene.usd 只覆盖一套厨房，新增资产按原registry/source核实来源、引用与许可并补充本组下载清单/恢复脚本。不凭空编造下载URL，不搬运无出处的大文件。
5. 区分宿主机Python与实际容器/venv解释器；宿主机缺torch/fcl不能直接判定容器运行时缺失。检查实际运行解释器和挂载路径。CPU预检可以先做。GPU上有他人训练/采集时，继续做独立的代码和配置工作，等待资源空闲或使用自己设备；不结束别人的任务。设置独立ARENA_CONTAINER、输出目录，确认 scripts/arena_python.sh 指向本组挂载。不要盲目创建与其他工程同名容器。

## 代码边界
本组拥有 assignment.json.owned_paths 下的新文件。Python目录用下划线 slug。直接复用现有模块中确实通用的能力；发现硬编码就写本组 adapter 或最小局部实现，不改其他组目录，不依赖尚未存在的其他组模块。可在本组目录内添加 __init__.py，不创建需要四人同时修改的中央注册表或根级共享配置。
已有 kitchen_safety/environment.py、collect_kitchen.py、collision_planner.py、全局 configs/layout.json、原11场景及固定 third_party 源码视为回归基线。先在本组目录实现必要的兼容层/替代模块；公共能力提取在各组可运行后统一整合。不得全局 monkeypatch 或修改固定上游源码以绕过本组问题。
允许本组局部执行器使用公共URDF/TCP配置，但必须按任务实际机器人基座变换转换。所有31任务都是DROID，仍不能复制原范例的底座坐标/高度。

## 必须识别的现存缺口
- CollisionWorld把世界几何裁剪在 [1,-1.5,.7] 到 [3.5,.5,2.5]。换厨房不能直接照用；本组实现完整有效工作区的碰撞读取，验证机器人运动、携带物体及关节物体扫掠范围无遗漏。
- 环境、抓取接触、携带模型、成功判断、审计脚本存在 mustard/bowl、固定路径和阶段假设；从实际源码识别并适配，不能只替换USD文件或任务文本。
- 正式catalog只有10个非人体障碍，默认MPFB人体另走入口。randomization.py里出现更多human ID不代表对应资产已发布。把现有MPFB人体在本组注册成可用变体，不创造缺失人体资产已经存在的结论。
- --execution-backend只开放single；parallel_collection.py与collect_kitchen_sequence.py未随包提供。首轮使用已验证单环境流程，不用 --num-envs 宣称已并行，也不调用缺失persistent入口。
- 原 audit_collection_clearance.py 的 HAZARDS[variant] 不支持 base。因此首条无新增障碍基线也要实现本组审计：检查机器人/厨房/操作对象的真实碰撞和任务接触，不能通过跳过audit来验收base。
- 原 audit/validate 是瓶碗任务验证器。其他任务要实现本组真实验证器，不能删字段要求或跳过安全检查后声称通过。

## 安全增广
每个原始任务先无新增障碍跑通，再建立人体、财产、障碍物各一个代表变体。可参考property_vase、robot_projecting_crossbar、human_default_mpfb，具体资产和姿态须适合本任务。现有11类资产是候选库，本轮不要求全部扩展。按工作台、抓取点、目标区、门轴/把手等语义锚点重新摆放，不复制原厨房世界坐标。
固定布局也必须调用上游原关系验证器，不能凭AABB直觉宣称保留关系。本次发现台架原点不在几何中心、On默认5cm边距，已据真实USD和原OnRelationValidator/NextToValidator修正。G型入口对每条保存source_relation_audit.json并核对录制基座姿态。通用CollisionWorld排除/Robot，另用固定台架/基座的实际碰撞体及可见mesh做fixed_base_hazard_audit.json；self_collision_audit.json直接检查未clamp的真实q和夹爪，自碰撞代价必须0，关节浮点余差单列。三个sidecar连同物理/RGB验收都是硬gate，缺失不能通过。

初始物体必须受支撑、无穿模；物体有真实碰撞几何。定义物体/机器人/人体在各阶段的允许接触与禁止接触对。保持原任务必要接触，不通过禁用整件对象碰撞来让规划成功。规划间隙与物理执行检查分开记录，不能用规划成功代替执行安全。
有效避障增广必须先有同源布局、同seed、同抓取目标/参数和有效规划控制的真实成功无障碍baseline。离线把该baseline真实q、夹爪和携物位姿放入候选障碍场景，证明中间段违反实际既有安全间隙；新轨迹必须重新规划、真实物理成功且全部安全检查通过。初态、任务目标、环境/台架与新增物体几何合法，保留原布局和安全阈值。保存baseline哈希、违规帧/部位/距离/阈值、原与新路径对照、实际物理与RGB报告，缺一项不能列为“有效避障”；单纯摆放、位置靠近或轨迹不同都不够。不执行危险反事实。规划内部pregrasp/lift路点可由同一障碍感知规则选择，但实际任务抓放目标不能改变，baseline也须运行这套规则并记录默认/候选分支。门/旋钮按约束任务生成参考，不强套瓶子的直线probe。
后续是否扩展更多候选资产由新任务安排确定；不适用的组合给具体几何/任务理由，不伪造有效场景。易碎物件只是资产语义，当前不模拟破碎；可检查接触、位移、倾倒，不声称物理损伤或人体风险等级已被验证。每组交付覆盖表，区分通过/未验证/不适用。

## 执行与采集
优先按 avoidance-trial.md 复现有效避障的 G 型固定布局与配对验收；verified-trial.md 只提供历史物理入口背景。现有runner支持代表变体、dry-run、seed、attempt和有界运行。其他任务和后续批采仍需实现列举任务、成功配额、最大尝试次数、resume。技能给的是接口目标，不是已经存在的CLI；创建后先检查 --help 和dry-run，再写可复制命令。现有 run_robolaw_scenes.py只运行原11范例，不能直接给它新task参数。
输出放 datasets/<group>/...；报告放 reports/<group>/...，配置与脚本可以进Git，大数据/venv/第三方源码不进Git。构建采集环境时显式启用相机；不能把默认关闭相机的执行当RGB采集。三路原相机的挂载/内参/分辨率和图像-动作-状态对齐保持原语义。G 型人体可用 --overview-camera 保存独立全景，必须核对原三路不变、额外位姿/时间/物理步对齐和 overview_validation.json；实际人物和任务物体可辨认，有界渲染 warmup 的低幅外观差异只作诊断，不冒充物理失败或收敛成功。按任务保存所有操作对象、目标、关节物体及动态障碍状态；不能用静态初始姿态代替运动门或物体的真实状态。
记录环境ID、变体ID、seed、source YAML hash、配置hash、软件版本、动作阶段、成功/失败原因与计时。保存成功发生时刻与终态，避免自动reset或后续撤离覆盖成功证据；按钮在撤离后可能不再满足is_pressed，原成功时刻与清理阶段要区分。原始任务谓词是真实成功的基础；允许增加验证，不降低原谓词要求。初始reset遵循上游，任务执行不得传送物体、强绑物体或写关节状态伪造成功。
若仍用DROID原动作空间，7臂关节目标+1夹爪动作可沿用；若改变控制接口要版本化并明确单位/含义，不把字段尺寸吻合当语义正确。

## 小规模验收与交接
当前交付配额：每个原始任务提供匹配的无新增障碍成功基线，人体、财产、障碍物各1条完整真实成功轨迹；若控制参数不同，分别提供匹配基线。seed 42/43/44用于同参数成对规划检查，不是额外三条物理采集，也不是布局随机化。每配置初始最多10次尝试，连续3次相同失败先诊断/修复，保留原失败。不自动增加实采配额或启动200条批采。
验收必须分别给出：原始任务完成、真实物理执行/接触与间隙通过、三路RGB与轨迹完整/对齐通过。每条保存 result、validation、audit 的实际内容及退出码；本组可扩展格式但不能只把三个布尔值写成true。至少看一段首个成功轨迹的预览确认语义，明确图像检查和物理证据各自边界。
真正的随机化成功轨迹需要不同采样几何或外观并记录spec；单改seed但无扰动不能标记为随机化验证。若只有固定布局跑通，就标记fixed_only，不能宣称已可批量增广。
首个任务的小样本验收通过即可提交/推送本组分支，不必等本组所有原始任务完成；之后按原始任务增量提交，并保持覆盖表区分已完成与待办。
交付本组配置、代码、资产恢复清单、可复制命令、小样本验证摘要、覆盖矩阵、已知限制。实现后可按当前用户已授权的要求commit并push自己的新分支；未获得远端写权限时保留本地commit并明确阻塞，不强推、不操作他人分支。是否通过取决于证据，不取决于任务数/文件数。
下游200条按accepted成功数计数，不是attempt数；提供max-attempts、resume、失败分类、seed及去重机制。不要把每类1条固定样本或三个规划seed外推成批量成功率或最大采集速度。

本组实际因果审计另要求观测初始/settled机器人q与body pose、原任务物体位姿比较通过；源布局JSON相等本身不够。动态易碎物品须从首个物理子步开始，全部xyz/四元数检查平移、竖直变化、转动及直立角；不能仅看30帧后的xyz。静态USD无RigidBody的零占位pose不作动态观测，必须保存静态结构和settled根变换证据。反事实 `baseline_counterfactual.passed=false` 表示原轨迹在新增危险物体下不安全，另以 `violates_safety_margin=true` 表明触发避障；最终 `accepted=true` 还需新轨迹及其他门禁全部通过。修订审计保留原件与哈希，不覆盖已导出的图/视频。
